<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-5 p-5">
    <?php if(Session::has('msg')): ?>
        <?php echo $__env->make('toast',[
            'msg' => Session::get('msg')
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <?php endif; ?>

    <?php if(Session::has('errors')): ?>
    <?php if(old('old_value') == "add_role"): ?>
    <script type="text/javascript">
        $(function () {
                    $('#insert_model').modal();
                    $('#insert_model').addClass('show');
                });
    </script>
    <?php endif; ?>
    <?php if(old('old_value') == "update_role"): ?>
    <script type="text/javascript">
        window.onload = () =>
                    {
                        document.querySelector('[data-target="#edit_model"]').click();
                    }
    </script>
    <?php endif; ?>
    <?php endif; ?>
    <div class="card p-4">
        <div class="card-header">
            <div class="row align-items-center">
                <div class="col-8">
                    <h1><?php echo e(__('Role')); ?></h1>
                </div>
                <div class="col-4 text-right">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_add')): ?>
                        <button type="button" class="btn btn-primary" onclick="add_btn()" data-toggle="modal" data-target="#insert_model">
                            <?php echo e(__('+ Add Role')); ?>

                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="table-responsive pt-3">
            <table class="table table-flush" id="datatable-basic">
                <thead class="thead-light">
                    <tr>
                        <th><?php echo e(__('#')); ?></th>
                        <th><?php echo e(__('Role name')); ?></th>
                        <th><?php echo e(__('permissions')); ?></th>
                        <?php if(Gate::check('role_edit')): ?>
                        <th><?php echo e(__('Action')); ?></th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($role->name); ?></td>
                        <td>
                            <?php $__empty_1 = true; $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <span class="badge badge-pill badge-primary"><?php echo e($permission->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <span class="badge badge-pill badge-primary"></span>
                            <?php endif; ?>
                        </td>
                        <?php if(Gate::check('role_edit')): ?>
                        <td class="table-actions">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_edit')): ?>
                            <a href="#" class="table-action ml-2" data-toggle="modal" data-target="#edit_model"
                                onclick="role_edit(<?php echo e($role->id); ?>)">
                                <i class="fas fa-user-edit"></i>
                            </a>
                            <?php endif; ?>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal right fade" id="insert_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h1><?php echo e(__('Add Role')); ?></h1>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(url('admin/role')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="old_value" value="add_role">
                    <div class="form-group">
                        <label class="form-control-label"><?php echo e(__('Name')); ?></label>
                        <input type="text" name="name" required class="form-control" style="text-transform: none">

                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label"><?php echo e(__('Permissions')); ?></label>
                        <select name="permissions[]"
                            class="select2 form-control <?php $__errorArgs = ['permissions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required multiple
                            dir="<?php echo e(session()->has('direction')&& session('direction') == 'rtl'? 'rtl':''); ?>">
                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($permission->id); ?>"><?php echo e($permission->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <span class="invalid-feedback" role="alert">
                        </span>
                    </div>

                    <hr class="my-3">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                        <input type="submit" value="<?php echo e(__('Save')); ?>" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal right fade" id="edit_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h1><?php echo e(__('Update Role')); ?></h1>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="edit_role" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="hidden" name="old_value" value="update_role">
                    <div class="form-group">
                        <label class="form-control-label"><?php echo e(__('Name')); ?></label>
                        <input type="text" name="name" id="update_name" readonly class="form-control"
                            style="text-transform: none">
                        <span class="invalid-feedback name" role="alert">
                        </span>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label"><?php echo e(__('Permissions')); ?></label>
                        <select name="permissions[]" id="update_permission"
                            class="select2 form-control <?php $__errorArgs = ['permissions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required multiple
                            dir="<?php echo e(session()->has('direction')&& session('direction') == 'rtl'? 'rtl':''); ?>">
                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($permission->id); ?>"><?php echo e($permission->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <span class="invalid-feedback permissions" role="alert">
                        </span>
                    </div>

                    <hr class="my-3">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                        <input type="submit" value="<?php echo e(__('Update role')); ?>" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'role'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\finallXampp\htdocs\laravel\shinewash\shinewash\resources\views/admin/role/role.blade.php ENDPATH**/ ?>