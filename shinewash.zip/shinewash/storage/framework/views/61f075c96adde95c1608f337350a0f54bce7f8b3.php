<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-5">
    <div class="card">
        <div class="card w-75 invoice_card" id="invoice_card">
            <div class="text-right">
                <a href="<?php echo e(url('admin/invoice_print/'.$data->id)); ?>" target="_blank" class="btn btn-primary">print</a>
            </div>
            <div class="card-header">
                <div class="col-12 text-center">
                    <h1><?php echo e(__('Invoice')); ?></h1>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="offset-md-1 col-md-3">
                        <b><?php echo e(__('Shop Details')); ?></b><br>
                        <?php echo e($company_data->company_address); ?>

                    </div>
                    <div class="offset-md-4 col-md-3">
                        <img src="<?php echo e(url('images/upload/'.$company_data->company_logo)); ?>" width="150" height="100" alt="">
                    </div>
                </div>
                <hr class="my-3">
                <div class="row">
                    <div class="offset-md-1 col-md-3">
                        <b><?php echo e(__('Invoice to')); ?></b><br><br>
                        <b><?php echo e(__('User')); ?></b><br>
                        <?php echo e($data->user['email']); ?>

                        <?php echo e($data->user['phone']); ?>

                    </div>
                    <div class="offset-md-4 col-md-3">
                        <b><?php echo e(__('Booking Id : ')); ?></b> <?php echo e($data->appointment_id); ?><br>
                        <b><?php echo e(__('Booking date : ')); ?></b> <?php echo e($data->date); ?><br>
                        <b><?php echo e(__('Booking time : ')); ?></b> <?php echo e($data->start_time); ?><br>
                        <b><?php echo e(__('payment type : ')); ?></b> <?php echo e($data->payment_type); ?><br>
                        <b><?php echo e(__('Booking status : ')); ?></b><?php echo e($data->appointment_status); ?><br>
                    </div>
                </div>
                <div class="row pt-5">
                    <div class="offset-md-1 col-md-10 offset-md-1">
                        <table class="table align-items-center text-center table-flush">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" class="sort" data-sort="name"><?php echo e(__('#')); ?></th>
                                    <th scope="col" class="sort" data-sort="budget"><?php echo e(__('Service name')); ?></th>
                                    <th scope="col" class="sort" data-sort="status"><?php echo e(__('price')); ?></th>
                                </tr>
                            </thead>
                            <tbody class="list">
                                <tr>
                                    <?php $__currentLoopData = $data['service']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->service_name); ?></td>
                                        <td><?php echo e($company_data->currency_symbol); ?><?php echo e($item->price); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="row pt-5">
                    <div class="col-md-11 text-right">
                        <b><?php echo e(__('Total : ')); ?></b> <?php echo e($company_data->currency_symbol); ?><?php echo e($data->amount); ?><br>
                        <b><?php echo e(__('discount : ')); ?></b>
                        <?php if($data->discount == null): ?>
                            <?php echo e($company_data->currency_symbol); ?>00<br>
                        <?php else: ?>
                            <?php echo e($company_data->currency_symbol); ?><?php echo e($data->discount); ?><br>
                        <?php endif; ?>
                        <b><?php echo e(__('Total payment : ')); ?></b> <?php echo e($company_data->currency_symbol); ?><?php echo e($data->amount + $data->discount); ?><br>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'appointment'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\finallXampp\htdocs\laravel\shinewash\shinewash\resources\views/admin/appointment/invoice.blade.php ENDPATH**/ ?>