<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-5">
    <div class="card">
        <div class="card-header">
            <button class="btn btn-sm pending"><?php echo e(__('Pending')); ?></button>
            <button class="btn btn-sm cancel"><?php echo e(__('Cancel')); ?></button>
            <button class="btn btn-sm reject"><?php echo e(__('Reject')); ?></button>
            <button class="btn btn-sm complete"><?php echo e(__('Complete')); ?></button>
            <button class="btn btn-sm approve"><?php echo e(__('Approve')); ?></button>
        </div>
        <div class="card-body">
            <div id="calender">
                <?php echo $calendar->calendar(); ?>

                <?php echo $calendar->script(); ?>

            </div>
        </div>
    </div>

    <div class="modal right fade" id="show_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form action="<?php echo e(url('admin/coworkers')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h1><?php echo e(__('appointment detail')); ?></h1>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <div class="file-upload text-center p-1">
                            <img src="" id="user_image" width="150" height="150" class="rounded-lg"/>
                        </div>

                        <table class="table">
                            <tr>
                                <td><?php echo e(__('Appointment Id')); ?></td>
                                <td id="appointment_id"></td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('Name')); ?></td>
                                <td id="user_name"></td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('Coworker name')); ?></td>
                                <td id="Coworker_name"></td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('service name')); ?></td>
                                <td id="service_name"></td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('Service at')); ?></td>
                                <td id="service_at"></td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('Date')); ?></td>
                                <td id="date"></td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('start time')); ?></td>
                                <td id="start_time"></td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('end time')); ?></td>
                                <td id="end_time"></td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('Duration')); ?></td>
                                <td id="duration"></td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('Amount')); ?></td>
                                <td id="amount"></td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('payment status')); ?></td>
                                <td id="payment_status"></td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('Appointment status')); ?></td>
                                <td id="appointment_status"></td>
                            </tr>
                        </table>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'calendar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\finallXampp\htdocs\laravel\shinewash\shinewash\resources\views/admin/calendar/calender.blade.php ENDPATH**/ ?>