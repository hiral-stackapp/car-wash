<nav class="navbar navbar-top navbar-expand navbar-dark bg-primary border-bottom">
    <div class="container-fluid">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <!-- Navbar links -->
            <ul class="navbar-nav align-items-center  ml-md-auto ">
                <li class="nav-item d-xl-none">
                    <!-- Sidenav toggler -->
                    <div class="pr-3 sidenav-toggler sidenav-toggler-dark active" data-action="sidenav-pin" data-target="#sidenav-main">
                    <div class="sidenav-toggler-inner">
                        <i class="sidenav-toggler-line"></i>
                        <i class="sidenav-toggler-line"></i>
                        <i class="sidenav-toggler-line"></i>
                    </div>
                    </div>
                </li>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
                <?php if(Auth::user()->load('roles')->roles->contains('name', 'admin')): ?>
                    <?php
                        $langs = \App\Language::where('status',1)->get();
                        $icon = \App\Language::where('name',session('locale'))->first();
                        if($icon)
                        {
                            $lang_image="/images/upload/".$icon->image;
                        }
                        else
                        {
                            $lang_image="/images/upload/usa.png";
                        }
                    ?>
                    <ul class="navbar-nav align-items-center  ml-auto ml-md-0 flag-ul">
                        <li class="nav-item dropdown rtl-flag">
                            <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false">
                                <div class="media align-items-center">
                                    <span class="avatar avatar-sm">
                                        <img class="small_round flag" src="<?php echo e(asset($lang_image)); ?>">
                                    </span>
                                </div>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-flag ">
                                <div class="dropdown-header noti-title">
                                    <h6 class="text-overflow m-0"><?php echo e(__('Language')); ?></h6>
                                </div>
                                <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(url('/admin/change_language/'.$lang->name)); ?>" class="dropdown-item">
                                    <span class="avatar avatar-sm">
                                        <img class="small_round flag" src="<?php echo e(asset('images/upload/'.$lang->image)); ?>">
                                    </span>
                                    <span><?php echo e($lang->name); ?></span>
                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </li>
                    </ul>
                <?php endif; ?>
                <?php if(Auth::user()->load('roles')->roles->contains('name', 'admin')): ?>
                    <ul class="navbar-nav align-items-center  ml-auto ml-md-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <div class="media align-items-center">
                                <span class="avatar avatar-sm rounded-circle">
                                    <img src="<?php echo e(url('images/upload/'.auth()->user()->image)); ?>" alt="">
                                </span>
                                <div class="media-body  ml-2  d-none d-lg-block">
                                <span class="mb-0 text-sm  font-weight-bold"><?php echo e(auth()->user()->name); ?></span>
                                </div>
                            </div>
                            </a>
                            <div class="dropdown-menu  dropdown-menu-right ">
                            <div class="dropdown-header noti-title">
                                <h6 class="text-overflow m-0"><?php echo e(__('Welcome!')); ?></h6>
                            </div>
                            <a href="<?php echo e(url('admin/admin_edit')); ?>" class="dropdown-item">
                                <i class="ni ni-single-02"></i>
                                <span><?php echo e(__('My profile')); ?></span>
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="<?php echo e(route('logout')); ?>" class="dropdown-item" onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                                        <i class="ni ni-user-run"></i>
                                        <span><?php echo e(__('Logout')); ?></span>
                            </a>
                            </div>

                        </li>
                    </ul>
                <?php else: ?>
                <?php
                    $worker = App\Coworkers::where('user_id',auth()->user()->id)->first();
                ?>
                <ul class="navbar-nav align-items-center ml-auto ml-md-0">
                    <li class="nav-item dropdown">
                        <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <div class="media align-items-center">
                            <span class="avatar avatar-sm rounded-circle">
                                <img src="<?php echo e(url('images/upload/'.$worker->image)); ?>" alt="">
                            </span>
                            <div class="media-body  ml-2  d-none d-lg-block">
                            <span class="mb-0 text-sm  font-weight-bold"><?php echo e($worker->name); ?></span>
                            </div>
                        </div>
                        </a>
                        <div class="dropdown-menu  dropdown-menu-right ">
                            <div class="dropdown-header noti-title">
                                <h6 class="text-overflow m-0"><?php echo e(__('Welcome!')); ?></h6>
                            </div>
                            <a href="<?php echo e(url('coworker/worker_profile')); ?>" class="dropdown-item">
                                <i class="ni ni-single-02"></i>
                                <span><?php echo e(__('My profile')); ?></span>
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="<?php echo e(route('logout')); ?>" class="dropdown-item" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                    <i class="ni ni-user-run"></i>
                                    <span><?php echo e(__('Logout')); ?></span>
                            </a>
                        </div>
                    </li>
                </ul>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH D:\finallXampp\htdocs\laravel\shinewash\shinewash\resources\views/layouts/navbars/navbar.blade.php ENDPATH**/ ?>