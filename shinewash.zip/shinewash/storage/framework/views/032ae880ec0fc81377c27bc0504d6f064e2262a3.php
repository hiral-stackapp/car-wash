<?php $__env->startSection('content'); ?>

<div class="container-fluid mt-5 p-5">
    <?php if(Session::has('msg')): ?>
    <?php echo $__env->make('toast',[
        'msg' => Session::get('msg')
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <?php endif; ?>

    <?php if(Session::has('errors')): ?>
        <?php if(old('old_value') == "add_appointment"): ?>
            <script type="text/javascript">
                $(function () {
                    $('#insert_model').modal();
                    $('#insert_model').addClass('show');
                });
            </script>
        <?php endif; ?>
        <?php if(old('old_value') == "add_user"): ?>
            <script type="text/javascript">
                $(function () {
                    $('#insert_model_user').modal();
                    $('#insert_model_user').addClass('show');
                });
            </script>
        <?php endif; ?>
    <?php endif; ?>
    <div class="card p-4">
        <div class="card-header">
            <div class="row align-items-center">
                <div class="col-8">
                    <h1><?php echo e(__('Appointment')); ?></h1>
                </div>
                <div class="col-4 text-right">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin_appointment_add')): ?>
                    <button type="button" class="btn btn-primary" onclick="add_btn()" data-toggle="modal" data-target="#insert_model">
                        <?php echo e(__('+ Add Appointment')); ?>

                    </button>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_add')): ?>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#insert_model_user">
                            <?php echo e(__('+ Add User')); ?>

                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="table-responsive pt-3">
            <table class="table" id="datatable-basic">
                <thead class="thead-light">
                    <tr>
                        <th><?php echo e(__('appointment Id')); ?></th>
                        <th><?php echo e(__('User')); ?></th>
                        <th><?php echo e(__('date')); ?></th>
                        <th><?php echo e(__('coworker')); ?></th>
                        <th><?php echo e(__('service')); ?></th>
                        <th><?php echo e(__('duration')); ?></th>
                        <th><?php echo e(__('amount')); ?></th>
                        <th><?php echo e(__('Service At')); ?></th>
                        <th><?php echo e(__('Appointment status')); ?></th>
                        <?php if(Gate::check('admin_appointment_delete') || Gate::check('admin_appointment_show') || Gate::check('appointment_invoice')): ?>
                            <th><?php echo e(__('Action')); ?></th>
                        <?php endif; ?>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $appoinments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appoinment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($appoinment->appointment_id); ?></td>
                        <td><?php echo e($appoinment->user['name']); ?></td>
                        <td><?php echo e($appoinment->date); ?></td>
                        <td><?php echo e($appoinment->coworker['name']); ?></td>
                        <td>
                            <?php $__currentLoopData = $appoinment->service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($item->service_name); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e($appoinment->duration); ?> <?php echo e(__('min')); ?></td>
                        <td><?php echo e($currency); ?><?php echo e($appoinment->amount); ?></td>
                        <td><?php echo e($appoinment->service_type); ?></td>
                        <td>
                            <select onchange="appointment_status(<?php echo e($appoinment->id); ?>)" id="appointment_status<?php echo e($appoinment->id); ?>" <?php echo e($appoinment->appointment_status == 'COMPLETE' ? 'disabled' : ''); ?> <?php echo e($appoinment->appointment_status == 'CANCEL' ? 'disabled' : ''); ?> class="form-control">
                                <option value="pending" <?php echo e($appoinment->appointment_status == 'PENDING' ? 'selected' : 'disabled'); ?>><?php echo e(__('Pending')); ?></option>
                                <option value="accept" <?php echo e($appoinment->appointment_status == 'ACCEPT' ? 'selected' : ''); ?>><?php echo e(__('Accept')); ?></option>
                                <option value="approve" <?php echo e($appoinment->appointment_status == 'APPROVE' ? 'selected' : ''); ?>><?php echo e(__('Approve')); ?></option>
                                <option value="cancel" <?php echo e($appoinment->appointment_status == 'CANCEL' ? 'selected' : ''); ?>><?php echo e(__('Cancel')); ?></option>
                                <option value="complete" <?php echo e($appoinment->appointment_status == 'COMPLETE' ? 'selected' : ''); ?>><?php echo e(__('Complete')); ?></option>
                            </select>
                        </td>
                        <?php if(Gate::check('admin_appointment_delete') || Gate::check('admin_appointment_show') || Gate::check('appointment_invoice')): ?>
                        <td class="table-actions">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin_appointment_delete')): ?>
                            <a href="#" class="table-action ml-2 table-action-delete" onclick="deleteData('admin/appointment',<?php echo e($appoinment->id); ?>)">
                                <i class="fas fa-trash"></i>
                            </a>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin_appointment_show')): ?>
                                <a href="#" class="table-action ml-2" data-toggle="modal" data-target="#show_model" onclick="appoinment_show(<?php echo e($appoinment->id); ?>)">
                                    <i class="fas fa-eye"></i>
                                </a>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('appointment_invoice')): ?>
                                <a href="<?php echo e(url('admin/appointment_invoice/'.$appoinment->id)); ?>" class="ml-2"><i class="fas fa-file-invoice"></i></a>
                            <?php endif; ?>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal right fade" id="insert_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="<?php echo e(url('admin/appointment')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="old_value" value="add_appointment">
                <div class="modal-header">
                    <h1><?php echo e(__('Add Appointment')); ?></h1>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label class="form-control-label"><?php echo e(__('User name')); ?></label>
                        <select class="select2 <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-toggle="select" title="<?php echo e(__('select user')); ?>" name="user_id"
                                data-placeholder="<?php echo e(__('Select a user')); ?>">
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>" <?php echo e((collect(old('user_id'))->contains($user->id)) ? 'selected':''); ?>><?php echo e($user->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label"><?php echo e(__('category')); ?></label><br>
                            <select class="select2 <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-toggle="select" title="<?php echo e(__('select category')); ?>" id="category_id" name="category_id[]" data-placeholder="<?php echo e(__('Select a category')); ?>">
                                <option value="0"><?php echo e(__('select category')); ?></option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php echo e((collect(old('category_id'))->contains($category->id)) ? 'selected':''); ?>><?php echo e($category->category_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label"><?php echo e(__('Coworker')); ?></label><br>
                            <select class="select2 <?php $__errorArgs = ['coworker_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                data-toggle="select" title="select coworker" id="appointment_coworker_id" name="coworker_id"
                                data-placeholder="<?php echo e(__('Select a Coworker')); ?>">
                                <option value="0"><?php echo e(__('select Coworker')); ?></option>
                                <?php $__currentLoopData = $coworkers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coworker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($coworker->id); ?>" <?php echo e((collect(old('coworker_id'))->contains($coworker->id)) ? 'selected':''); ?>><?php echo e($coworker->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php $__errorArgs = ['coworker_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label"><?php echo e(__('service')); ?></label><br>
                            <select class="select2 <?php $__errorArgs = ['service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                data-toggle="select" id="service" title="<?php echo e(__('select service')); ?>" name="service_id[]"
                                data-placeholder="Select service" multiple>

                            </select>

                            <?php $__errorArgs = ['service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label"><?php echo e(__('Select date')); ?></label><br>
                        <input class="flatpickr flatpickr-input form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="appointment_calender" name="date" type="text" placeholder="<?php echo e(__('Select Date')); ?>">

                        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label"><?php echo e(__('Timeslot')); ?></label><br>
                            <select class="select2 <?php $__errorArgs = ['start_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-toggle="select" id="timeslot" title="select time" name="start_time" data-placeholder="<?php echo e(__('Select time')); ?>">

                            </select>

                            <?php $__errorArgs = ['start_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <hr class="my-3">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                        <input type="submit" value="<?php echo e(__('Save')); ?>" class="btn btn-primary">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal right fade" id="show_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h1><?php echo e(__('Appointment detail')); ?></h1>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <div class="text-center">
                    <img src="" id="user_image" width="200" height="200" class="rounded-lg p-2">
                </div>
                <table class="table">
                    <tr>
                        <td><?php echo e(__('Appointment')); ?></td>
                        <td id="show_appointment"></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('User')); ?></td>
                        <td id="show_user"></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Duration in min')); ?></td>
                        <td id="show_duration"></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Service')); ?></td>
                        <td id="show_service"></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Amount')); ?></td>
                        <td id="show_amount"></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Coworker')); ?></td>
                        <td id="show_coworker"></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Date')); ?></td>
                        <td id="show_date"></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Start time')); ?></td>
                        <td id="show_start_time"></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('End time')); ?></td>
                        <td id="show_end_time"></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Service At')); ?></td>
                        <td id="show_service_at"></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Appointment Status')); ?></td>
                        <td id="show_appointment_status"></td>
                    </tr>

                    <tr>
                        <td><?php echo e(__('Payment Status')); ?></td>
                        <td id="show_payment_status"></td>
                    </tr>

                    <tr>
                        <td><?php echo e(__('Payment Type')); ?></td>
                        <td id="show_payment_type"></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal right fade" id="insert_model_user" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="<?php echo e(url('admin/user')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="old_value" value="add_user">
                <div class="modal-header">
                    <h1><?php echo e(__('Add User')); ?></h1>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <div class="file-upload">
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" name="image" accept=".png, .jpg, .jpeg, .svg" id="customFileLang" lang="en">
                                <label class="custom-file-label" for="customFileLang"><?php echo e(__('Select file')); ?></label>
                            </div>
                        </div>
                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="custom_error" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label"><?php echo e(__('user name')); ?></label>
                        <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name')); ?>" name="name" type="text" placeholder="name">

                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label"><?php echo e(__('phone')); ?></label>
                        <input class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('phone')); ?>" name="phone" type="number" placeholder="<?php echo e(__('phone number')); ?>" style="text-transform: none">

                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label"><?php echo e(__('password')); ?></label>
                        <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" type="password" style="text-transform: none">

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label"><?php echo e(__('email')); ?></label>
                        <input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" name="email" type="email" placeholder="<?php echo e(__('email')); ?>"  style="text-transform: none">

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <hr class="my-3">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                        <input type="submit" value="<?php echo e(__('Save')); ?>" class="btn btn-primary">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'appointment'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\finallXampp\htdocs\laravel\shinewash\shinewash\resources\views/admin/appointment/appointment.blade.php ENDPATH**/ ?>