<?php $__env->startSection('setting'); ?>
<div class="container-fluid mt-5">
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-lg-3 col-md-4">
                    <ul class="nav nav-pills nav-pills-rose nav-pills-icons flex-column" role="tablist">
                        <?php if(App\Setting::find(1)->license_verify == 1): ?>
                        <li class="nav-item active">
                            <a class="nav-link mt-1 w-100 h-100 show active" data-toggle="tab" href="#link110"
                                role="tablist" aria-expanded="true">
                                <?php echo e(__('Company core setting')); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mt-1 w-100 h-100" data-toggle="tab" href="#link111" role="tablist"
                                aria-expanded="false">
                                <?php echo e(__('payment setting')); ?>

                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link mt-1 w-100 h-100" data-toggle="tab" href="#link113" role="tablist"
                                aria-expanded="false">
                                <?php echo e(__('User verification')); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mt-1 w-100 h-100" data-toggle="tab" href="#link112" role="tablist"
                                aria-expanded="false">
                                <?php echo e(__('Notification setting')); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mt-1 w-100 h-100" data-toggle="tab" href="#link117" role="tablist"
                                aria-expanded="false">
                                <?php echo e(__('Coworker Notification setting')); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mt-1 w-100 h-100" data-toggle="tab" href="#link114" role="tablist"
                                aria-expanded="false">
                                <?php echo e(__('Privacy policy')); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mt-1 w-100 h-100" data-toggle="tab" href="#link115" role="tablist"
                                aria-expanded="false">
                                <?php echo e(__('Admin setting')); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mt-1 w-100 h-100" data-toggle="tab" href="#link116" role="tablist"
                                aria-expanded="false">
                                <?php echo e(__('License setting')); ?>

                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item show active">
                            <a class="nav-link mt-1 w-100 h-100" data-toggle="tab" href="#link116" role="tablist"
                                aria-expanded="false">
                                <?php echo e(__('License setting')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    </ul>
                </div>

                <div class="offset-md-1 col-md-6">
                    <div class="tab-content">
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible fade show message_alert error_alert" role="alert">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($item); ?> <br>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endif; ?>
                        <?php if(App\Setting::find(1)->license_verify == 1): ?>
                            <div class="tab-pane show active" id="link110">
                                <form action="<?php echo e(url('admin/update_setting')); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="form-control-label"><?php echo e(__('Company Logo')); ?></label>
                                                <div class="text-center">
                                                    <img src="<?php echo e(url('images/upload/'.$company_setting->company_logo)); ?>" id="update_image" width="200" height="200" class="rounded-lg p-2"/>
                                                </div>
                                                <div class="form-group">
                                                    <div class="custom-file">
                                                        <input type="file" class="custom-file-input" name="company_logo" accept=".png, .jpg, .jpeg, .svg" id="customFileLang1" lang="en">
                                                        <label class="custom-file-label" for="customFileLang1"><?php echo e(__('Select file')); ?></label>
                                                    </div>
                                                </div>

                                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-md-6">
                                                <label class="form-control-label"><?php echo e(__('Company Favicon')); ?> </label>
                                                <div class="text-center">
                                                    <img src="<?php echo e(url('images/upload/'.$company_setting->company_favicon)); ?>" id="update_image" width="200" height="200" class="rounded-lg p-2"/>
                                                </div>
                                                <div class="form-group">
                                                    <div class="custom-file">
                                                        <input type="file" class="custom-file-input" name="company_favicon" accept=".png, .jpg, .jpeg, .svg" id="customFileLang" lang="en">
                                                        <label class="custom-file-label" for="customFileLang"><?php echo e(__('Select file')); ?></label>
                                                    </div>
                                                </div>

                                                <?php $__errorArgs = ['company_favicon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('currency')); ?></label>
                                        <select class="form-control select2 <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-toggle="select" title="select currency" name="currency" data-placeholder="Select a currency" id="currency"  dir="<?php echo e(session()->has('direction')&& session('direction') == 'rtl'? 'rtl':''); ?>>
                                            <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($currency->code); ?>" <?php echo e($company_setting->currency == $currency->code ? 'selected' : ''); ?>><?php echo e($currency->country); ?>&nbsp;&nbsp;(<?php echo e($currency->currency); ?>)&nbsp;&nbsp;(<?php echo e($currency->code); ?>)
                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('Company name')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e($company_setting->company_name); ?>" name="company_name" type="text"
                                            placeholder="company name" style="text-transform:none;">
                                        <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <?php
                                        $lat = App\Setting::find(1)->latitude;
                                        $lang = App\Setting::find(1)->longitude;
                                    ?>

                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('Company address')); ?></label>
                                        <div id="map-custom" class="map-canvas" data-lat="<?php echo e($lat); ?>" data-lng="<?php echo e($lang); ?>"
                                            style="height: 300px;"></div>
                                        <input type="hidden" name="latitude" id="lat" value="<?php echo e($lat); ?>">
                                        <input type="hidden" name="longitude" id="lang" value="<?php echo e($lang); ?>">
                                        <textarea name="company_address" class="form-control <?php $__errorArgs = ['company_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="company_address" cols="30" rows="10" placeholder="company address"
                                            style="text-transform:none;"><?php echo e($company_setting->company_address); ?></textarea>

                                        <?php $__errorArgs = ['company_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('Phone number')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e($company_setting->phone); ?>" name="phone" type="text"
                                            placeholder="phone number" style="text-transform:none;">

                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('Website')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e($company_setting->website); ?>" name="website" type="text"
                                            placeholder="website" style="text-transform:none;">
                                        <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('map key')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['map_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e($company_setting->map_key); ?>" name="map_key" type="text"
                                            placeholder="map key" style="text-transform:none;">
                                        <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <hr class="my-3">
                                    <div class="text-center">
                                        <input type="submit" value="<?php echo e(__('Save')); ?>" class="btn btn-primary">
                                    </div>
                                </form>
                            </div>

                            <div class="tab-pane" id="link111">
                                <form action="<?php echo e(url('admin/update_payment_setting')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label class="form-control-label"><?php echo e(__('Service paid locally')); ?></label><br>
                                            <label class="custom-toggle">
                                                <input type="checkbox" name="cod"
                                                    <?php echo e($payment_setting->cod == 1 ? 'checked' : ''); ?>>
                                                <span class="custom-toggle-slider rounded-circle" data-label-off="<?php echo e(__('no')); ?>" data-label-on="<?php echo e(__('yes')); ?>"></span>
                                            </label>
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-control-label"><?php echo e(__('Paypal')); ?></label><br>
                                            <label class="custom-toggle">
                                                <input type="checkbox" name="paypal"
                                                    <?php echo e($payment_setting->paypal == 1 ? 'checked' : ''); ?>>
                                                <span class="custom-toggle-slider rounded-circle" data-label-off="<?php echo e(__('no')); ?>" data-label-on="<?php echo e(__('yes')); ?>"></span>
                                            </label>
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-control-label"><?php echo e(__('Stripe')); ?></label><br>
                                            <label class="custom-toggle">
                                                <input type="checkbox" name="stripe"
                                                    <?php echo e($payment_setting->stripe == 1 ? 'checked' : ''); ?>>
                                                <span class="custom-toggle-slider rounded-circle" data-label-off="<?php echo e(__('no')); ?>" data-label-on="<?php echo e(__('yes')); ?>"></span>
                                            </label>
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-control-label"><?php echo e(__('Razorpay')); ?></label><br>
                                            <label class="custom-toggle">
                                                <input type="checkbox" name="razorpay"
                                                    <?php echo e($payment_setting->razorpay == 1 ? 'checked' : ''); ?>>
                                                <span class="custom-toggle-slider rounded-circle" data-label-off="<?php echo e(__('no')); ?>" data-label-on="<?php echo e(__('yes')); ?>"></span>
                                            </label>
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-control-label"><?php echo e(__('Flutterwave')); ?></label><br>
                                            <label class="custom-toggle">
                                                <input type="checkbox" name="flutterwave" <?php echo e($payment_setting->flutterwave == 1 ? 'checked' : ''); ?>>
                                                <span class="custom-toggle-slider rounded-circle" data-label-off="<?php echo e(__('no')); ?>" data-label-on="<?php echo e(__('yes')); ?>"></span>
                                            </label>
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-control-label"><?php echo e(__('PayStack')); ?></label><br>
                                            <label class="custom-toggle">
                                                <input type="checkbox" name="paystack" <?php echo e($payment_setting->paystack == 1 ? 'checked' : ''); ?>>
                                                <span class="custom-toggle-slider rounded-circle" data-label-off="<?php echo e(__('no')); ?>" data-label-on="<?php echo e(__('yes')); ?>"></span>
                                            </label>
                                        </div>
                                    </div>

                                    <div class="form-group mt-5">
                                        <label for="usr"><?php echo e(__('PayPal Environment Sandbox')); ?></label>
                                        <input type="text"
                                            class="form-control <?php $__errorArgs = ['paypal_sendbox'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="paypal_sendbox" id="paypal-username"
                                            style="width:100%; text-transform: none"
                                            value="<?php echo e($payment_setting->paypal_sendbox); ?>">

                                        <?php $__errorArgs = ['paypal_sendbox'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>

                                    <div class="form-group">
                                        <label for="usr"><?php echo e(__('PayPal Environment Production')); ?></label>
                                        <input type="text"
                                            class="form-control <?php $__errorArgs = ['paypal_production'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="paypal_production" id="paypal-password"
                                            style="width:100%; text-transform: none"
                                            value="<?php echo e($payment_setting->paypal_production); ?>">

                                        <?php $__errorArgs = ['paypal_production'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="usr"><?php echo e(__('Stripe Published Key')); ?></label>
                                        <input type="text"
                                            class="form-control <?php $__errorArgs = ['stripe_publish_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="stripe_publish_key" id="strip-publish"
                                            style="width:100%; text-transform: none"
                                            value="<?php echo e($payment_setting->stripe_publish_key); ?>">

                                        <?php $__errorArgs = ['stripe_publish_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="usr"><?php echo e(__('Stripe Secret Key')); ?></label>
                                        <input type="text"
                                            class="form-control <?php $__errorArgs = ['stripe_secret_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="stripe_secret_key" id="strip-secret"
                                            style="width:100%; text-transform: none"
                                            value="<?php echo e($payment_setting->stripe_secret_key); ?>">

                                        <?php $__errorArgs = ['stripe_secret_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="usr"><?php echo e(__('Razorpay key')); ?></label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['razorpay_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="razorpay_key" id="razorpay_key" style="width:100%; text-transform: none"
                                            value="<?php echo e($payment_setting->razorpay_key); ?>">
                                        <?php $__errorArgs = ['razorpay_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="usr"><?php echo e(__('Flutterwave public key')); ?></label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['flutterwave_public_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="flutterwave_public_key" id="flutterwave_public_key" style="width:100%; text-transform: none"
                                            value="<?php echo e($payment_setting->flutterwave_public_key); ?>">
                                        <?php $__errorArgs = ['flutterwave_public_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="usr"><?php echo e(__('Paystack public key')); ?></label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['paystack_public_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="paystack_public_key" id="paystack_public_key" style="width:100%; text-transform: none"
                                            value="<?php echo e($payment_setting->paystack_public_key); ?>">
                                        <?php $__errorArgs = ['paystack_public_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <div class="text-center">
                                            <input type="submit" value="<?php echo e(__('Save')); ?>" class="btn btn-primary">
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <div class="tab-pane" id="link112">
                                <form action="<?php echo e(url('admin/update_notification_setting')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="form-control-label"><?php echo e(__('Push notification')); ?></label><br>
                                                <label class="custom-toggle">
                                                    <input type="checkbox" name="push_notification"
                                                        <?php echo e($company_setting->push_notification == 1 ? 'checked' : ''); ?>>
                                                    <span class="custom-toggle-slider rounded-circle" data-label-off="<?php echo e(__('no')); ?>" data-label-on="<?php echo e(__('yes')); ?>"></span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="form-control-label"><?php echo e(__('Mail notification')); ?></label><br>
                                                <label class="custom-toggle">
                                                    <input type="checkbox" name="mail_notification"
                                                        <?php echo e($company_setting->mail_notification == 1 ? 'checked' : ''); ?>>
                                                    <span class="custom-toggle-slider rounded-circle" data-label-off="<?php echo e(__('no')); ?>" data-label-on="<?php echo e(__('yes')); ?>"></span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('Onesignal App Id')); ?></label><br>
                                        <input type="text"
                                            class="form-control <?php $__errorArgs = ['onesignal_app_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="onesignal_app_id" style="text-transform: none"
                                            placeholder="Onesignal App Id" value="<?php echo e($company_setting->onesignal_app_id); ?>">

                                        <?php $__errorArgs = ['onesignal_app_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('Onesignal auth key')); ?></label><br>
                                        <input type="text"
                                            class="form-control <?php $__errorArgs = ['onesignal_auth_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="onesignal_auth_key" style="text-transform: none"
                                            placeholder="Onesignal auth key"
                                            value="<?php echo e($company_setting->onesignal_auth_key); ?>">

                                        <?php $__errorArgs = ['onesignal_auth_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('Onesignal Rest api key')); ?></label><br>
                                        <input type="text" class="form-control <?php $__errorArgs = ['rest_api_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="rest_api_key" style="text-transform: none"
                                            placeholder="Onesignal Rest api key"
                                            value="<?php echo e($company_setting->rest_api_key); ?>">

                                        <?php $__errorArgs = ['rest_api_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('project number')); ?></label><br>
                                        <input type="text"
                                            class="form-control <?php $__errorArgs = ['project_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="project_number" style="text-transform: none" placeholder="project number"
                                            value="<?php echo e($company_setting->project_number); ?>">

                                        <?php $__errorArgs = ['project_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('Mail host')); ?></label><br>
                                        <input type="text" class="form-control <?php $__errorArgs = ['mail_host'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="mail_host" style="text-transform: none" placeholder="mail host"
                                            value="<?php echo e($company_setting->mail_host); ?>">

                                        <?php $__errorArgs = ['mail_host'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('Mail port')); ?></label><br>
                                        <input type="text" class="form-control <?php $__errorArgs = ['mail_port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="mail_port" style="text-transform: none" placeholder="mail port"
                                            value="<?php echo e($company_setting->mail_port); ?>">

                                        <?php $__errorArgs = ['mail_port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('Mail user name')); ?></label><br>
                                        <input type="text" class="form-control <?php $__errorArgs = ['mail_username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="mail_username" style="text-transform: none" placeholder="mail user name"
                                            value="<?php echo e($company_setting->mail_username); ?>">

                                        <?php $__errorArgs = ['mail_username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('Mail password')); ?></label><br>
                                        <input type="password"
                                            class="form-control <?php $__errorArgs = ['mail_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="mail_password" style="text-transform: none" placeholder="mail password"
                                            value="<?php echo e($company_setting->mail_password); ?>">

                                        <?php $__errorArgs = ['mail_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('Mail encryption')); ?></label><br>
                                        <input type="text"
                                            class="form-control <?php $__errorArgs = ['mail_encryption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="mail_encryption" style="text-transform: none"
                                            placeholder="mail encryption" value="<?php echo e($company_setting->mail_encryption); ?>">

                                        <?php $__errorArgs = ['mail_encryption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('Mail from address')); ?></label><br>
                                        <input type="text"
                                            class="form-control <?php $__errorArgs = ['mail_from_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="mail_from_address" style="text-transform: none"
                                            placeholder="mail from address"
                                            value="<?php echo e($company_setting->mail_from_address); ?>">

                                        <?php $__errorArgs = ['mail_from_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group setting-button">
                                        <div class="text-center">
                                            <input type="submit" value="<?php echo e(__('Save')); ?>" class="btn btn-primary">
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <div class="tab-pane" id="link113">
                                <form action="<?php echo e(url('admin/update_user_verification')); ?>" method="post">
                                    <?php echo csrf_field(); ?>

                                    <div class="alert bg-primary text-white" style="display: none" role="alert">
                                       <?php echo e(__('At least select one mail or sms')); ?>

                                    </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label class="form-control-label"><?php echo e(__('User verification')); ?></label><br>
                                            <label class="custom-toggle">
                                                <input type="checkbox" id="user_verification" name="user_verification"
                                                    <?php echo e($company_setting->user_verification == 1 ? 'checked' : ''); ?>>
                                                <span class="custom-toggle-slider rounded-circle" data-label-off="<?php echo e(__('no')); ?>" data-label-on="<?php echo e(__('yes')); ?>"></span>
                                            </label>
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-control-label"><?php echo e(__('User verify by sms')); ?></label><br>
                                            <label class="custom-toggle">
                                                <input type="checkbox" name="sms_verification" id="sms_verification"
                                                    <?php echo e($company_setting->sms_verification == 1 ? 'checked' : ''); ?>>
                                                <span class="custom-toggle-slider rounded-circle"  data-label-off="<?php echo e(__('no')); ?>" data-label-on="<?php echo e(__('yes')); ?>"></span>
                                            </label>
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-control-label"><?php echo e(__('User verify by email')); ?></label><br>
                                            <label class="custom-toggle">
                                                <input type="checkbox" name="mail_verification" id="mail_verification"
                                                    <?php echo e($company_setting->mail_verification == 1 ? 'checked' : ''); ?>>
                                                <span class="custom-toggle-slider rounded-circle" data-label-off="<?php echo e(__('no')); ?>" data-label-on="<?php echo e(__('yes')); ?>"></span>
                                            </label>
                                        </div>
                                    </div>

                                    <div class="form-group mt-5">
                                        <label for="usr"><?php echo e(__('Twilio account id')); ?></label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['twilio_acc_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="twilio_acc_id" style="width:100%; text-transform: none"
                                            value="<?php echo e($company_setting->twilio_acc_id); ?>">

                                        <?php $__errorArgs = ['twilio_acc_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="usr"><?php echo e(__('twilio auth token')); ?></label>
                                        <input type="text"
                                            class="form-control <?php $__errorArgs = ['twilio_auth_token'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="twilio_auth_token" style="width:100%; text-transform: none"
                                            value="<?php echo e($company_setting->twilio_auth_token); ?>">

                                        <?php $__errorArgs = ['twilio_auth_token'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="usr"><?php echo e(__('twilio phone number')); ?></label>
                                        <input type="text"
                                            class="form-control <?php $__errorArgs = ['twilio_phone_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="twilio_phone_no" style="width:100%; text-transform: none"
                                            value="<?php echo e($company_setting->twilio_phone_no); ?>">

                                        <?php $__errorArgs = ['twilio_phone_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <div class="text-center">
                                            <input type="submit" value="<?php echo e(__('Save')); ?>" class="btn btn-primary">
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <div class="tab-pane" id="link114">
                                <form action="<?php echo e(url('admin/update_privacy_policy')); ?>" method="post">
                                    <?php echo csrf_field(); ?>

                                    <div class="form-group mt-5">
                                        <label for="usr"><?php echo e(__('Privacy policy')); ?></label>
                                        <textarea name="privacy_policy" class="form-control textarea_editor" cols="10"
                                            rows="10" id="privacy_policy"
                                            style="text-transform: none"><?php echo e($company_setting->privacy_policy); ?></textarea>
                                    </div>

                                    <div class="form-group">
                                        <div class="text-center">
                                            <input type="submit" value="<?php echo e(__('Save')); ?>" class="btn btn-primary">
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <div class="tab-pane" id="link115">
                                <form action="<?php echo e(url('admin/change_color')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('Service at home')); ?></label><br>
                                        <label class="custom-toggle">
                                            <input type="checkbox" name="service_at_home" id="service_at_home"
                                                <?php echo e($company_setting->service_at_home == 1 ? 'checked' : ''); ?>>
                                            <span class="custom-toggle-slider rounded-circle" data-label-off="<?php echo e(__('No')); ?>"
                                                data-label-on="<?php echo e(__('Yes')); ?>"></span>
                                        </label>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('Color')); ?></label><br>
                                        <input type="color" name="color" value="<?php echo e($company_setting->color); ?>" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <input type="submit" value="<?php echo e(__('Save')); ?>" class="btn btn-primary">
                                    </div>
                                </form>
                            </div>
                                <div class="tab-pane" id="link116">
                                    <form action="<?php echo e(url('admin/update_license')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label class="form-control-label"><?php echo e(__('license code')); ?></label><br>
                                            <input type="text" class="form-control <?php $__errorArgs = ['license_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="license_code" style="text-transform: none"
                                                placeholder="license code" value="<?php echo e($company_setting->license_code); ?>" readonly>

                                            <?php $__errorArgs = ['license_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group">
                                            <label class="form-control-label"><?php echo e(__('client name')); ?></label><br>
                                            <input type="text" class="form-control <?php $__errorArgs = ['client_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="client_name" style="text-transform: none"
                                                placeholder="client name" value="<?php echo e($company_setting->client_name); ?>" readonly>
                                            <?php $__errorArgs = ['client_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group">
                                            <div class="text-center">
                                                <input type="submit" value="<?php echo e(__('Save')); ?>" class="btn btn-primary" disabled>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            <?php else: ?>
                                <div class="tab-pane show active" id="link116">
                                    <form action="<?php echo e(url('admin/update_license')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label class="form-control-label"><?php echo e(__('license code')); ?></label><br>
                                            <input type="text" class="form-control <?php $__errorArgs = ['license_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="license_code" style="text-transform: none"
                                                placeholder="license code" value="<?php echo e($company_setting->license_code); ?>" required>

                                            <?php $__errorArgs = ['license_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group">
                                            <label class="form-control-label"><?php echo e(__('client name')); ?></label><br>
                                            <input type="text" class="form-control <?php $__errorArgs = ['client_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="client_name" style="text-transform: none"
                                                placeholder="client name" value="<?php echo e($company_setting->client_name); ?>" required>

                                            <?php $__errorArgs = ['client_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group">
                                            <div class="text-center">
                                                <input type="submit" value="<?php echo e(__('Save')); ?>" class="btn btn-primary">
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            <?php endif; ?>

                            <div class="tab-pane" id="link117">
                                <form action="<?php echo e(url('admin/update_coworker_notification_setting')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('Coworker notification')); ?></label><br>
                                        <label class="custom-toggle">
                                            <input type="checkbox" name="coworker_notification"
                                                <?php echo e($company_setting->coworker_notification == 1 ? 'checked' : ''); ?>>
                                            <span class="custom-toggle-slider rounded-circle" data-label-off="<?php echo e(__('no')); ?>" data-label-on="<?php echo e(__('yes')); ?>"></span>
                                        </label>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('Coworker Onesignal App Id')); ?></label><br>
                                        <input type="text"
                                            class="form-control <?php $__errorArgs = ['coworker_app_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="coworker_app_id" style="text-transform: none"
                                            placeholder="Coworker App Id" value="<?php echo e($company_setting->coworker_app_id); ?>">

                                        <?php $__errorArgs = ['coworker_app_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('coworker auth key')); ?></label><br>
                                        <input type="text"
                                            class="form-control <?php $__errorArgs = ['coworker_auth_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="coworker_auth_key" style="text-transform: none"
                                            placeholder="coworker auth key"
                                            value="<?php echo e($company_setting->coworker_auth_key); ?>">

                                        <?php $__errorArgs = ['coworker_auth_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('Coworker Rest api key')); ?></label><br>
                                        <input type="text" class="form-control <?php $__errorArgs = ['coworker_rest_api_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="coworker_rest_api_key" style="text-transform: none"
                                            placeholder="Coworker Rest api key"
                                            value="<?php echo e($company_setting->coworker_rest_api_key); ?>">

                                        <?php $__errorArgs = ['coworker_rest_api_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e(__('coworker project number')); ?></label><br>
                                        <input type="text"
                                            class="form-control <?php $__errorArgs = ['coworker_project_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="coworker_project_number" style="text-transform: none" placeholder="coworker project number"
                                            value="<?php echo e($company_setting->coworker_project_number); ?>">

                                        <?php $__errorArgs = ['coworker_project_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group setting-button">
                                        <div class="text-center">
                                            <input type="submit" value="<?php echo e(__('Save')); ?>" class="btn btn-primary">
                                        </div>
                                    </div>
                                </form>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'setting'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\finallXampp\htdocs\laravel\shinewash\shinewash\resources\views/admin/setting/setting.blade.php ENDPATH**/ ?>