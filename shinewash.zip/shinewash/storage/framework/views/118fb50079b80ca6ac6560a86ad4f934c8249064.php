<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="header-body">
        <div class="row align-items-center py-4">

        </div>
        <!-- Card stats -->
        <div class="row">
            <div class="col-xl-4 col-md-6">
                <div class="card card-stats">
                    <!-- Card body -->
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <h5 class="card-title text-uppercase text-muted mb-0"><?php echo e(__('Total appointment')); ?></h5>
                                <span class="h2 font-weight-bold mb-0"><?php echo e($appointments); ?></span>
                            </div>
                            <div class="col-auto">
                                <div class="icon icon-shape bg-gradient-red text-white rounded-circle shadow">
                                    <i class="far fa-calendar-check"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-6">
                <div class="card card-stats">
                    <!-- Card body -->
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <h5 class="card-title text-uppercase text-muted mb-0"><?php echo e(__('Total reviews')); ?></h5>
                                <span class="h2 font-weight-bold mb-0"><?php echo e($reviews); ?></span>
                            </div>
                            <div class="col-auto">
                                <div class="icon icon-shape bg-gradient-orange text-white rounded-circle shadow">
                                    <i class="fas fa-file-pdf"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-6">
                <div class="card card-stats">
                    <!-- Card body -->
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <h5 class="card-title text-uppercase text-muted mb-0"><?php echo e(__('Today appointments')); ?></h5>
                                <span class="h2 font-weight-bold mb-0"><?php echo e(count($today_appointments)); ?></span>
                            </div>
                            <div class="col-auto">
                                <div class="icon icon-shape bg-gradient-orange text-white rounded-circle shadow">
                                    <i class="fas fa-file-pdf"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-5">
        <div class="card-header">
            <h4><?php echo e(__('Todays appointments')); ?></h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table datatable">
                    <thead class="thead-light">
                        <tr>
                            <th><?php echo e(__('appointment Id')); ?></th>
                            <th><?php echo e(__('User')); ?></th>
                            <th><?php echo e(__('coworker')); ?></th>
                            <th><?php echo e(__('service')); ?></th>
                            <th><?php echo e(__('duration')); ?></th>
                            <th><?php echo e(__('amount')); ?></th>
                            <th><?php echo e(__('Service At')); ?></th>
                            <th><?php echo e(__('Appointment status')); ?></th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $today_appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $today_appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($today_appointment->appointment_id); ?></td>
                            <td><?php echo e($today_appointment->user['name']); ?></td>
                            <td><?php echo e($today_appointment->coworker['name']); ?></td>
                            <td>
                                <?php $__currentLoopData = $today_appointment->service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($item->service_name); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><?php echo e($today_appointment->duration); ?> <?php echo e(__('min')); ?></td>
                            <td><?php echo e($currency); ?><?php echo e($today_appointment->amount); ?></td>
                            <td><?php echo e($today_appointment->service_type); ?></td>
                            <td><?php echo e($appointment->appointment_status); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app',['activePage' => 'dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\finallXampp\htdocs\laravel\shinewash\shinewash\resources\views/coworker/coworker/coworker_home.blade.php ENDPATH**/ ?>